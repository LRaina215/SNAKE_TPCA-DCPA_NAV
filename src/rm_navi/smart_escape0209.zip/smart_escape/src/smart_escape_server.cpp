#include "smart_escape/smart_escape_server.hpp"
#include <cmath>
#include <vector>
#include <algorithm>
#include "geometry_msgs/msg/twist.hpp" // 【关键】确保包含这个

namespace smart_escape
{

SmartEscapeServer::SmartEscapeServer(const rclcpp::NodeOptions & options)
: Node("smart_escape_server", options)
{
  // 1. 声明参数
  declare_parameter("global_frame", "map");
  declare_parameter("robot_base_frame", "base_link");
  declare_parameter("robot_radius", 0.35); // 确保与头文件变量对应
  declare_parameter("escape_distance", 0.5);
  
  // 2. 获取参数
  global_frame_ = get_parameter("global_frame").as_string();
  robot_base_frame_ = get_parameter("robot_base_frame").as_string();
  robot_radius_ = get_parameter("robot_radius").as_double();
  escape_distance_ = get_parameter("escape_distance").as_double();
  
  // 3. 初始化 Action Server
  action_server_ = rclcpp_action::create_server<SmartEscape>(
    this,
    "smart_escape",
    std::bind(&SmartEscapeServer::handle_goal, this, std::placeholders::_1, std::placeholders::_2),
    std::bind(&SmartEscapeServer::handle_cancel, this, std::placeholders::_1),
    std::bind(&SmartEscapeServer::handle_accepted, this, std::placeholders::_1)
  );

  // 4. 初始化 Costmap 订阅
  costmap_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
    "local_costmap/costmap_raw", 10,
    [this](const nav_msgs::msg::OccupancyGrid::SharedPtr msg) {
      std::lock_guard<std::mutex> lock(costmap_mutex_);
      current_costmap_ = msg;
    });

  // 5. 【新增】初始化速度发布者
  vel_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", 10);
  
  // 6. 初始化 TF
  tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
  tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
  
  RCLCPP_INFO(this->get_logger(), "SmartEscape Server (Omni-Directional) Initialized!");
}

rclcpp_action::GoalResponse SmartEscapeServer::handle_goal(
  const rclcpp_action::GoalUUID & uuid,
  std::shared_ptr<const SmartEscape::Goal> goal)
{
  (void)uuid;
  (void)goal;
  RCLCPP_INFO(this->get_logger(), "Received escape request");
  return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
}

rclcpp_action::CancelResponse SmartEscapeServer::handle_cancel(
  const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  (void)goal_handle;
  RCLCPP_INFO(this->get_logger(), "Received cancel request");
  return rclcpp_action::CancelResponse::ACCEPT;
}

void SmartEscapeServer::handle_accepted(const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  std::thread{std::bind(&SmartEscapeServer::execute_escape, this, std::placeholders::_1), goal_handle}.detach();
}

void SmartEscapeServer::execute_escape(const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  RCLCPP_INFO(this->get_logger(), "Start executing omni-escape...");
  
  rclcpp::Rate loop_rate(10); // 10Hz
  auto result = std::make_shared<SmartEscape::Result>();
  
  geometry_msgs::msg::Pose initial_pose;
  if (!getRobotPose(initial_pose)) {
    RCLCPP_ERROR(this->get_logger(), "Failed to get robot pose");
    goal_handle->abort(result);
    return;
  }

  double target_dist = escape_distance_; 
  double traveled_dist = 0.0;

  while (rclcpp::ok()) {
    // Check cancel
    if (goal_handle->is_canceling()) {
      geometry_msgs::msg::Twist stop_cmd;
      vel_pub_->publish(stop_cmd);
      goal_handle->canceled(result);
      return;
    }

    // Update distance
    geometry_msgs::msg::Pose current_pose;
    if (getRobotPose(current_pose)) {
      traveled_dist = std::hypot(current_pose.position.x - initial_pose.position.x,
                                 current_pose.position.y - initial_pose.position.y);
    }
    
    // Check success
    if (traveled_dist >= target_dist) {
      RCLCPP_INFO(this->get_logger(), "Escape succeeded! Moved %.2f m", traveled_dist);
      geometry_msgs::msg::Twist stop_cmd;
      vel_pub_->publish(stop_cmd);
      
      // 返回最后的 Pose 供参考 (虽然不用它做导航了)
      result->escape_pose.header.frame_id = global_frame_;
      result->escape_pose.header.stamp = this->now();
      result->escape_pose.pose = current_pose;
      goal_handle->succeed(result);
      return;
    }

    // Calculate velocity
    double vx = 0.0, vy = 0.0;
    {
      std::lock_guard<std::mutex> lock(costmap_mutex_);
      if (!current_costmap_) {
        RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 1000, "Waiting for local costmap...");
        loop_rate.sleep();
        continue;
      }
      calculate_escape_velocity(vx, vy); 
    }

    // Publish velocity
    geometry_msgs::msg::Twist cmd_vel;
    cmd_vel.linear.x = vx;
    cmd_vel.linear.y = vy;
    cmd_vel.angular.z = 0.0;
    vel_pub_->publish(cmd_vel);

    loop_rate.sleep();
  }
}

void SmartEscapeServer::calculate_escape_velocity(double &vx, double &vy)
{
    // 简化的全向逃逸逻辑：找最近的一圈 Free 区域的重心
    double search_radius = 2.0; 
    double speed = 0.4;
    int free_threshold = 10;
    
    double resolution = current_costmap_->info.resolution;
    // local costmap 通常是 rolling window，origin 会变，但相对于 robot 始终是一样的结构
    // 简单起见，我们假设 costmap 中心就是机器人 (对于 rolling window 来说通常如此)
    int width = current_costmap_->info.width;
    int height = current_costmap_->info.height;
    int center_x = width / 2;
    int center_y = height / 2;

    bool found = false;
    double best_dir_x = 0.0;
    double best_dir_y = 0.0;

    // 从机器人半径外开始搜索
    for (double r = robot_radius_ / resolution; r <= search_radius / resolution; r += 2.0) {
        std::vector<std::pair<double, double>> free_vecs;
        
        // 遍历圆周
        for (double theta = 0.0; theta < 2 * M_PI; theta += 0.2) {
            int dx = r * cos(theta);
            int dy = r * sin(theta);
            int mx = center_x + dx;
            int my = center_y + dy;

            if (mx >= 0 && mx < width && my >= 0 && my < height) {
                int idx = my * width + mx;
                int cost = current_costmap_->data[idx];
                // Costmap: 0=Free, 100=Lethal, -1=Unknown
                if (cost >= 0 && cost < 50) { 
                    free_vecs.push_back({cos(theta), sin(theta)});
                }
            }
        }

        if (free_vecs.size() > (size_t)free_threshold) {
            // 算重心
            double sum_x = 0, sum_y = 0;
            for (auto &p : free_vecs) { sum_x += p.first; sum_y += p.second; }
            best_dir_x = sum_x;
            best_dir_y = sum_y;
            found = true;
            break; // 找到最近的可行圈
        }
    }

    if (found) {
        double angle = atan2(best_dir_y, best_dir_x);
        vx = speed * cos(angle);
        vy = speed * sin(angle);
    } else {
        // 如果完全被围死，不要动，或者原地自旋 (但哨兵建议不动)
        vx = 0.0;
        vy = 0.0;
    }
}

bool SmartEscapeServer::getRobotPose(geometry_msgs::msg::Pose & robot_pose)
{
  try {
    geometry_msgs::msg::TransformStamped t;
    t = tf_buffer_->lookupTransform(global_frame_, robot_base_frame_, tf2::TimePointZero);
    robot_pose.position.x = t.transform.translation.x;
    robot_pose.position.y = t.transform.translation.y;
    robot_pose.position.z = t.transform.translation.z;
    robot_pose.orientation = t.transform.rotation;
    return true;
  } catch (tf2::TransformException & ex) {
    return false;
  }
}

} // namespace smart_escape
