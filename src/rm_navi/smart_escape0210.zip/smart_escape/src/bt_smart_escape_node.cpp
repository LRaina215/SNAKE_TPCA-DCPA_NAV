#include "smart_escape/bt_smart_escape_node.hpp"
#include "behaviortree_cpp_v3/bt_factory.h"

namespace nav2_behavior_tree
{

BtSmartEscapeNode::BtSmartEscapeNode(
  const std::string & xml_tag_name,
  const BT::NodeConfiguration & conf)
: BT::StatefulActionNode(xml_tag_name, conf),
  goal_sent_(false), result_received_(false), goal_accepted_(false)
{
  try {
    auto blackboard = config().blackboard;
    if (!blackboard) throw std::runtime_error("Blackboard is null");
    
    node_ = blackboard->get<rclcpp::Node::SharedPtr>("node");
    if (!node_) {
      if(!blackboard->get("ros_node", node_)) throw std::runtime_error("Could not get ROS node");
    }

    getInput("server_name", server_name_);
    getInput("server_timeout", server_timeout_);

    RCLCPP_INFO(node_->get_logger(), "BtSmartEscapeNode: initializing client for %s", server_name_.c_str());
    action_client_ = rclcpp_action::create_client<SmartEscape>(node_, server_name_);
  } 
  catch (const std::exception& e) {
    std::cerr << "Exception in BtSmartEscapeNode: " << e.what() << std::endl;
    throw; 
  }
}

BtSmartEscapeNode::~BtSmartEscapeNode() { cleanup(); }
void BtSmartEscapeNode::cleanup() { if (action_client_) action_client_.reset(); }

BT::NodeStatus BtSmartEscapeNode::onStart()
{
  if (!node_ || !action_client_) return BT::NodeStatus::FAILURE;

  goal_sent_ = false;
  result_received_ = false;
  goal_accepted_ = false;
  result_.reset();

  if (!action_client_->action_server_is_ready()) {
    RCLCPP_ERROR(node_->get_logger(), 
      "SmartEscape Action Server '%s' is NOT ready. Is the server running?", 
      server_name_.c_str());
    return BT::NodeStatus::FAILURE;
  }

  auto goal_msg = SmartEscape::Goal();
  auto send_goal_options = rclcpp_action::Client<SmartEscape>::SendGoalOptions();
  
  send_goal_options.goal_response_callback =
    std::bind(&BtSmartEscapeNode::goalResponseCallback, this, std::placeholders::_1);
  send_goal_options.result_callback =
    std::bind(&BtSmartEscapeNode::resultCallback, this, std::placeholders::_1);

  RCLCPP_INFO(node_->get_logger(), "Sending SmartEscape Goal...");
  action_client_->async_send_goal(goal_msg, send_goal_options);
  goal_sent_ = true;
  
  return BT::NodeStatus::RUNNING;
}

BT::NodeStatus BtSmartEscapeNode::onRunning()
{
  if (result_received_) {
    if (result_ && result_->success) {
      RCLCPP_INFO(node_->get_logger(), "SmartEscape Success! Target: [%.2f, %.2f]", 
                  result_->escape_pose.pose.position.x, result_->escape_pose.pose.position.y);
      setOutput("escape_pose", result_->escape_pose);
      return BT::NodeStatus::SUCCESS;
    } else {
      RCLCPP_WARN(node_->get_logger(), "SmartEscape Failed or Aborted.");
      return BT::NodeStatus::FAILURE;
    }
  }
  return BT::NodeStatus::RUNNING;
}

void BtSmartEscapeNode::onHalted()
{
  if (action_client_ && goal_sent_ && !result_received_) action_client_->async_cancel_all_goals();
  cleanup();
}

void BtSmartEscapeNode::goalResponseCallback(const ClientGoalHandle::SharedPtr & goal_handle)
{
  if (!goal_handle) {
    if(node_) RCLCPP_ERROR(node_->get_logger(), "SmartEscape Goal Rejected");
    goal_accepted_ = false;
    result_received_ = true; 
  } else {
    goal_accepted_ = true;
  }
}

void BtSmartEscapeNode::resultCallback(const ClientGoalHandle::WrappedResult & wrapped_result)
{
  result_received_ = true;
  if (wrapped_result.code == rclcpp_action::ResultCode::SUCCEEDED) result_ = wrapped_result.result;
}

void BtSmartEscapeNode::feedbackCallback(ClientGoalHandle::SharedPtr, const std::shared_ptr<const SmartEscape::Feedback>) {}

} // namespace nav2_behavior_tree

// =================================================================
// 【重要回退】这才是 Nav2 加载 BT 节点库的唯一方式！
// 不要用 PLUGINLIB_EXPORT_CLASS，因为 BT 库加载器不认它。
// =================================================================
extern "C" void BT_RegisterNodesFromPlugin(BT::BehaviorTreeFactory & factory)
{
  factory.registerNodeType<nav2_behavior_tree::BtSmartEscapeNode>("SmartEscape");
}