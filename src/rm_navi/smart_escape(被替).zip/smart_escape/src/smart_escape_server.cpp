#include "smart_escape/smart_escape_server.hpp"
#include <cmath>
#include <vector>
#include <algorithm>
// 【核心修正】Galactic 下必须包含 .h 版本，否则报找不到 .hpp
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "tf2/utils.h"

namespace smart_escape
{

SmartEscapeServer::SmartEscapeServer(const rclcpp::NodeOptions & options)
: Node("smart_escape_server", options)
{
  declare_parameter("global_frame", "map");
  declare_parameter("robot_base_frame", "base_link");
  declare_parameter("initial_radius", 0.5);      
  declare_parameter("max_radius", 2.0);          
  declare_parameter("radius_increment", 0.3);    
  declare_parameter("min_free_cells_threshold", 10); 
  declare_parameter("escape_distance", 0.3);     
  declare_parameter("transform_tolerance", 0.1);
  
  global_frame_ = get_parameter("global_frame").as_string();
  robot_base_frame_ = get_parameter("robot_base_frame").as_string();
  initial_radius_ = get_parameter("initial_radius").as_double();
  max_radius_ = get_parameter("max_radius").as_double();
  radius_increment_ = get_parameter("radius_increment").as_double();
  min_free_cells_threshold_ = get_parameter("min_free_cells_threshold").as_int();
  escape_distance_ = get_parameter("escape_distance").as_double();
  transform_tolerance_ = get_parameter("transform_tolerance").as_double();
  
  tf_buffer_ = std::make_shared<tf2_ros::Buffer>(get_clock());
  tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
  
  auto qos = rclcpp::QoS(1).transient_local().reliable();
  costmap_sub_ = create_subscription<nav_msgs::msg::OccupancyGrid>(
    "/global_costmap/costmap", qos,
    std::bind(&SmartEscapeServer::costmapCallback, this, std::placeholders::_1));
  
  action_server_ = rclcpp_action::create_server<SmartEscape>(
    this, "smart_escape",
    std::bind(&SmartEscapeServer::handle_goal, this, std::placeholders::_1, std::placeholders::_2),
    std::bind(&SmartEscapeServer::handle_cancel, this, std::placeholders::_1),
    std::bind(&SmartEscapeServer::handle_accepted, this, std::placeholders::_1));
  
  RCLCPP_INFO(get_logger(), "Smart Escape Server initialized (Full Algorithm)");
}

void SmartEscapeServer::costmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(costmap_mutex_);
  current_costmap_ = msg;
}

rclcpp_action::GoalResponse SmartEscapeServer::handle_goal(const rclcpp_action::GoalUUID &, std::shared_ptr<const SmartEscape::Goal>)
{ return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE; }

rclcpp_action::CancelResponse SmartEscapeServer::handle_cancel(const std::shared_ptr<GoalHandleSmartEscape>)
{ return rclcpp_action::CancelResponse::ACCEPT; }

void SmartEscapeServer::handle_accepted(const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{ std::thread{std::bind(&SmartEscapeServer::execute_escape, this, std::placeholders::_1), goal_handle}.detach(); }

void SmartEscapeServer::execute_escape(const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  auto result = std::make_shared<SmartEscape::Result>();
  geometry_msgs::msg::Pose robot_pose;
  if (!getRobotPose(robot_pose)) { result->success = false; goal_handle->abort(result); return; }
  geometry_msgs::msg::PoseStamped escape_pose;
  if (compute_escape_target(robot_pose, escape_pose)) {
    result->success = true; result->escape_pose = escape_pose; goal_handle->succeed(result);
  } else {
    result->success = false; goal_handle->abort(result);
  }
}

bool SmartEscapeServer::compute_escape_target(const geometry_msgs::msg::Pose & robot_pose, geometry_msgs::msg::PoseStamped & escape_pose)
{
  std::lock_guard<std::mutex> lock(costmap_mutex_);
  if (!current_costmap_) return false;
  unsigned int robot_mx, robot_my;
  if (!worldToMap(robot_pose.position.x, robot_pose.position.y, robot_mx, robot_my)) return false;
  
  double current_radius = initial_radius_;
  std::vector<std::pair<unsigned int, unsigned int>> free_cells;
  while (current_radius <= max_radius_) {
    free_cells.clear();
    int r_cells = static_cast<int>(current_radius / current_costmap_->info.resolution);
    for (int dy = -r_cells; dy <= r_cells; ++dy) {
      for (int dx = -r_cells; dx <= r_cells; ++dx) {
        if (dx * dx + dy * dy > r_cells * r_cells) continue;
        int mx = static_cast<int>(robot_mx) + dx, my = static_cast<int>(robot_my) + dy;
        if (mx < 0 || mx >= (int)current_costmap_->info.width || my < 0 || my >= (int)current_costmap_->info.height) continue;
        if (current_costmap_->data[my * current_costmap_->info.width + mx] == 0) free_cells.emplace_back(mx, my);
      }
    }
    if ((int)free_cells.size() >= min_free_cells_threshold_) break;
    current_radius += radius_increment_;
  }
  
  if ((int)free_cells.size() < min_free_cells_threshold_) return false;
  double avg_mx = 0, avg_my = 0;
  for (const auto & cell : free_cells) { avg_mx += cell.first; avg_my += cell.second; }
  avg_mx /= free_cells.size(); avg_my /= free_cells.size();
  double avg_wx, avg_wy; mapToWorld(avg_mx, avg_my, avg_wx, avg_wy);
  double escape_yaw = std::atan2(avg_wy - robot_pose.position.y, avg_wx - robot_pose.position.x);
  
  escape_pose.header.frame_id = global_frame_;
  escape_pose.header.stamp = now();
  escape_pose.pose.position.x = robot_pose.position.x + escape_distance_ * std::cos(escape_yaw);
  escape_pose.pose.position.y = robot_pose.position.y + escape_distance_ * std::sin(escape_yaw);
  tf2::Quaternion q; q.setRPY(0, 0, escape_yaw); escape_pose.pose.orientation = tf2::toMsg(q);
  return true;
}

bool SmartEscapeServer::getRobotPose(geometry_msgs::msg::Pose & robot_pose)
{
  geometry_msgs::msg::TransformStamped t;
  try { t = tf_buffer_->lookupTransform(global_frame_, robot_base_frame_, tf2::TimePointZero); }
  catch (tf2::TransformException & ex) { return false; }
  robot_pose.position.x = t.transform.translation.x; robot_pose.position.y = t.transform.translation.y;
  robot_pose.orientation = t.transform.rotation; return true;
}

bool SmartEscapeServer::worldToMap(double wx, double wy, unsigned int & mx, unsigned int & my)
{
  double origin_x = current_costmap_->info.origin.position.x, origin_y = current_costmap_->info.origin.position.y;
  double res = current_costmap_->info.resolution;
  if (wx < origin_x || wy < origin_y) return false;
  mx = (wx - origin_x) / res; my = (wy - origin_y) / res;
  return (mx < current_costmap_->info.width && my < current_costmap_->info.height);
}

bool SmartEscapeServer::mapToWorld(unsigned int mx, unsigned int my, double & wx, double & wy)
{
  wx = current_costmap_->info.origin.position.x + (mx + 0.5) * current_costmap_->info.resolution;
  wy = current_costmap_->info.origin.position.y + (my + 0.5) * current_costmap_->info.resolution;
  return true;
}

int SmartEscapeServer::getCost(unsigned int mx, unsigned int my)
{ return current_costmap_->data[my * current_costmap_->info.width + mx]; }

} // namespace smart_escape

#include "rclcpp_components/register_node_macro.hpp"
RCLCPP_COMPONENTS_REGISTER_NODE(smart_escape::SmartEscapeServer)