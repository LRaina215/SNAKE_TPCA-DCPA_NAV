#ifndef SMART_ESCAPE_SERVER_HPP_
#define SMART_ESCAPE_SERVER_HPP_

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
// 【修正】使用你自己的包名
#include "smart_escape/action/smart_escape.hpp"
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
// 【修正】Galactic 标准头文件是 .h
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

namespace smart_escape
{
// 【修正】命名空间必须对齐你自己包生成的接口
using SmartEscape = smart_escape::action::SmartEscape;
using GoalHandleSmartEscape = rclcpp_action::ServerGoalHandle<SmartEscape>;

class SmartEscapeServer : public rclcpp::Node
{
public:
  explicit SmartEscapeServer(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  rclcpp_action::Server<SmartEscape>::SharedPtr action_server_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr costmap_sub_;
  nav_msgs::msg::OccupancyGrid::SharedPtr current_costmap_;
  std::mutex costmap_mutex_;
  
  std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
  
  std::string global_frame_;
  std::string robot_base_frame_;
  double initial_radius_;
  double max_radius_;
  double radius_increment_;
  int min_free_cells_threshold_;
  double escape_distance_;
  double transform_tolerance_;
  
  rclcpp_action::GoalResponse handle_goal(
    const rclcpp_action::GoalUUID & uuid,
    std::shared_ptr<const SmartEscape::Goal> goal);
  rclcpp_action::CancelResponse handle_cancel(
    const std::shared_ptr<GoalHandleSmartEscape> goal_handle);
  void handle_accepted(const std::shared_ptr<GoalHandleSmartEscape> goal_handle);
  void execute_escape(const std::shared_ptr<GoalHandleSmartEscape> goal_handle);
  bool compute_escape_target(
    const geometry_msgs::msg::Pose & robot_pose,
    geometry_msgs::msg::PoseStamped & escape_pose);
  bool getRobotPose(geometry_msgs::msg::Pose & robot_pose);
  bool worldToMap(double wx, double wy, unsigned int & mx, unsigned int & my);
  bool mapToWorld(unsigned int mx, unsigned int my, double & wx, double & wy);
  int getCost(unsigned int mx, unsigned int my);
  void costmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg);
};
} // namespace smart_escape
#endif