#ifndef BT_SMART_ESCAPE_NODE_HPP_
#define BT_SMART_ESCAPE_NODE_HPP_

#include <string>
#include "rclcpp/rclcpp.hpp"
#include "nav2_behavior_tree/bt_action_node.hpp" 
#include "smart_escape/action/smart_escape.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"

// 改用我们自己的命名空间，避免混淆
namespace smart_escape
{

// 继承时使用 ::nav2_behavior_tree 确保编译器从全局范围查找
class BtSmartEscapeNode : public ::nav2_behavior_tree::BtActionNode<smart_escape::action::SmartEscape>
{
public:
  // 构造函数：标准签名
  BtSmartEscapeNode(const std::string & xml_tag_name, const BT::NodeConfiguration & conf)
  : ::nav2_behavior_tree::BtActionNode<smart_escape::action::SmartEscape>(xml_tag_name, "smart_escape", conf)
  {
  }

  static BT::PortsList providedPorts()
  {
    return providedBasicPorts({
      BT::OutputPort<geometry_msgs::msg::PoseStamped>("escape_pose", "Computed escape pose"),
      BT::OutputPort<std::string>("result_message", "Result message")
    });
  }

  BT::NodeStatus on_success() override
  {
    auto result = result_.result; 
    
    RCLCPP_INFO(node_->get_logger(), "SmartEscape Action Succeeded!");
    
    setOutput("escape_pose", result->escape_pose);
    
    // 【修正】根据日志，你的 Action 字段名应该是 message，不是 result_message
    // 如果编译再报错，就把它注释掉
    // setOutput("result_message", result->message); 
    
    return BT::NodeStatus::SUCCESS;
  }
};

} // namespace smart_escape

#endif