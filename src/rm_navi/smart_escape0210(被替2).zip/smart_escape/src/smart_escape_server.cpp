#include "smart_escape/smart_escape_server.hpp"
#include <cmath>
#include <vector>
#include <algorithm>
#include "geometry_msgs/msg/twist.hpp"

namespace smart_escape
{

SmartEscapeServer::SmartEscapeServer(const rclcpp::NodeOptions & options)
: Node("smart_escape_server", options)
{
  declare_parameter("global_frame", "map");
  declare_parameter("robot_base_frame", "base_link");
  declare_parameter("robot_radius", 0.4);
  declare_parameter("escape_distance", 0.3);
  
  global_frame_ = get_parameter("global_frame").as_string();
  robot_base_frame_ = get_parameter("robot_base_frame").as_string();
  robot_radius_ = get_parameter("robot_radius").as_double();
  escape_distance_ = get_parameter("escape_distance").as_double();
  
  // 1. 独立回调组
  auto sub_cb_group = this->create_callback_group(rclcpp::CallbackGroupType::Reentrant);
  rclcpp::SubscriptionOptions sub_options;
  sub_options.callback_group = sub_cb_group;

  // 2. 【核心修复】严格匹配 Nav2 的地图 QoS
  // Reliability: Reliable (因为地图不能丢)
  // Durability: Transient Local (因为地图是锁存的，后来者也要能收到)
  rclcpp::QoS map_qos(rclcpp::KeepLast(1));
  map_qos.reliable();
  map_qos.transient_local();

  // 3. 【核心修复】换话题！
  // 之前的 /local_costmap/costmap_raw 是 nav2_msgs/Costmap 类型，跟我们的代码不兼容
  // 现在的 /local_costmap/costmap 是 nav_msgs/OccupancyGrid 类型，完美兼容！
  costmap_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
    "/local_costmap/costmap", 
    map_qos, 
    [this](const nav_msgs::msg::OccupancyGrid::SharedPtr msg) {
      // 收到数据打印一次
      // RCLCPP_INFO_ONCE(this->get_logger(), ">>> 终于连上了！收到 Costmap 数据! <<<");
      std::lock_guard<std::mutex> lock(costmap_mutex_);
      current_costmap_ = msg;
    },
    sub_options);

  action_server_ = rclcpp_action::create_server<SmartEscape>(
    this,
    "smart_escape",
    std::bind(&SmartEscapeServer::handle_goal, this, std::placeholders::_1, std::placeholders::_2),
    std::bind(&SmartEscapeServer::handle_cancel, this, std::placeholders::_1),
    std::bind(&SmartEscapeServer::handle_accepted, this, std::placeholders::_1)
  );

  vel_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", 10);
  
  tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
  tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
  
  RCLCPP_INFO(this->get_logger(), "SmartEscape Server Initialized (OccupancyGrid Mode)");
}

rclcpp_action::GoalResponse SmartEscapeServer::handle_goal(
  const rclcpp_action::GoalUUID & uuid,
  std::shared_ptr<const SmartEscape::Goal> goal)
{
  (void)uuid; (void)goal;
  RCLCPP_INFO(this->get_logger(), "Received escape request");
  return rclcpp_action::GoalResponse::ACCEPT_AND_EXECUTE;
}

rclcpp_action::CancelResponse SmartEscapeServer::handle_cancel(
  const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  (void)goal_handle;
  RCLCPP_INFO(this->get_logger(), "Received cancel request");
  return rclcpp_action::CancelResponse::ACCEPT;
}

void SmartEscapeServer::handle_accepted(const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  std::thread{std::bind(&SmartEscapeServer::execute_escape, this, std::placeholders::_1), goal_handle}.detach();
}

void SmartEscapeServer::execute_escape(const std::shared_ptr<GoalHandleSmartEscape> goal_handle)
{
  RCLCPP_INFO(this->get_logger(), "Start executing omni-escape...");
  
  rclcpp::Rate loop_rate(10);
  auto result = std::make_shared<SmartEscape::Result>();
  
  geometry_msgs::msg::Pose initial_pose;
  if (!getRobotPose(initial_pose)) {
    RCLCPP_ERROR(this->get_logger(), "Failed to get robot pose");
    goal_handle->abort(result);
    return;
  }

  double target_dist = escape_distance_; 
  double traveled_dist = 0.0;

  while (rclcpp::ok()) {
    if (goal_handle->is_canceling()) {
      geometry_msgs::msg::Twist stop_cmd;
      vel_pub_->publish(stop_cmd);
      goal_handle->canceled(result);
      return;
    }

    geometry_msgs::msg::Pose current_pose;
    if (getRobotPose(current_pose)) {
      traveled_dist = std::hypot(current_pose.position.x - initial_pose.position.x,
                                 current_pose.position.y - initial_pose.position.y);
    }
    
    if (traveled_dist >= target_dist) {
      RCLCPP_INFO(this->get_logger(), "Escape succeeded! Moved %.2f m", traveled_dist);
      geometry_msgs::msg::Twist stop_cmd;
      vel_pub_->publish(stop_cmd);
      result->escape_pose.header.frame_id = global_frame_;
      result->escape_pose.header.stamp = this->now();
      result->escape_pose.pose = current_pose;
      goal_handle->succeed(result);
      return;
    }

    double vx = 0.0, vy = 0.0;
    bool has_map = false;

    // 锁只在访问数据时持有
    {
      std::lock_guard<std::mutex> lock(costmap_mutex_);
      if (current_costmap_) {
        has_map = true;
        calculate_escape_velocity(vx, vy); 
      }
    } 

    if (!has_map) {
      // 这里的 topic 名字也改了
      RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 2000, 
        "Waiting for local costmap on /local_costmap/costmap ...");
      loop_rate.sleep(); 
      continue;
    }

    geometry_msgs::msg::Twist cmd_vel;
    cmd_vel.linear.x = vx;
    cmd_vel.linear.y = vy;
    cmd_vel.angular.z = 0.0;
    vel_pub_->publish(cmd_vel);

    loop_rate.sleep();
  }
}

void SmartEscapeServer::calculate_escape_velocity(double &vx, double &vy)
{
    double search_radius = 2.0; 
    double speed = 0.4;
    int free_threshold = 10;
    
    double resolution = current_costmap_->info.resolution;
    int width = current_costmap_->info.width;
    int height = current_costmap_->info.height;
    int center_x = width / 2;
    int center_y = height / 2;

    bool found = false;
    double best_dir_x = 0.0;
    double best_dir_y = 0.0;

    for (double r = robot_radius_ / resolution; r <= search_radius / resolution; r += 2.0) {
        std::vector<std::pair<double, double>> free_vecs;
        for (double theta = 0.0; theta < 2 * M_PI; theta += 0.2) {
            int dx = r * cos(theta);
            int dy = r * sin(theta);
            int mx = center_x + dx;
            int my = center_y + dy;

            if (mx >= 0 && mx < width && my >= 0 && my < height) {
                int idx = my * width + mx;
                int cost = current_costmap_->data[idx];
                if (cost >= 0 && cost < 50) { 
                    free_vecs.push_back({cos(theta), sin(theta)});
                }
            }
        }

        if (free_vecs.size() > (size_t)free_threshold) {
            double sum_x = 0, sum_y = 0;
            for (auto &p : free_vecs) { sum_x += p.first; sum_y += p.second; }
            best_dir_x = sum_x;
            best_dir_y = sum_y;
            found = true;
            break; 
        }
    }

    if (found) {
        double angle = atan2(best_dir_y, best_dir_x);
        vx = speed * cos(angle);
        vy = speed * sin(angle);
    } else {
        vx = 0.0; vy = 0.0;
    }
}

bool SmartEscapeServer::getRobotPose(geometry_msgs::msg::Pose & robot_pose)
{
  try {
    geometry_msgs::msg::TransformStamped t;
    t = tf_buffer_->lookupTransform(global_frame_, robot_base_frame_, tf2::TimePointZero);
    robot_pose.position.x = t.transform.translation.x;
    robot_pose.position.y = t.transform.translation.y;
    robot_pose.position.z = t.transform.translation.z;
    robot_pose.orientation = t.transform.rotation;
    return true;
  } catch (tf2::TransformException & ex) {
    return false;
  }
}

} // namespace smart_escape