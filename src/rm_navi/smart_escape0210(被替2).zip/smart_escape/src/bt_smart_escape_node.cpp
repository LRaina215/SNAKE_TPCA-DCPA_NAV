#include "smart_escape/bt_smart_escape_node.hpp"
#include "behaviortree_cpp_v3/bt_factory.h"

// 必须使用 extern "C" 来让 Nav2 的 XML 加载器找到入口
extern "C" void BT_RegisterNodesFromPlugin(BT::BehaviorTreeFactory & factory)
{
  // 注册节点：类名现在是在 smart_escape 命名空间下
  factory.registerNodeType<smart_escape::BtSmartEscapeNode>("SmartEscape");
}