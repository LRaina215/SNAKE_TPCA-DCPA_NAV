'''
Robot communication dispatch layer, 
this module is the bridge between DDS and serial port hardware. 
Through the module, 
a BCP frame can be initialized to receive the data transmitted by DDS 
and send the data to MCU. 
At the same time, the data received by the onboard computer will also be 
transmitted to the DDS through this module 
to be received by other subscribers.
机器人通信调度层，该模块是DDS与串口硬件之间的桥梁。
通过模块，可以初始化一个BCP帧来接收DDS传输的数据并将数据发送给MCU。
同时，车载电脑接收到的数据也会通过该模块传输到DDS，由其他订户接收。
'''
import math
import time

from rclpy.node import Node
from rclpy import qos
from geometry_msgs.msg import PoseWithCovariance, Twist
from std_msgs.msg import Int8

from bubble_protocol.hardware import RobotSerial
from bubble_protocol.robot_status import RobotStatus
from rmctrl_msgs.msg import Chassis, Gimbal, Shooter
#from auto_aim_interfaces.msg import Target


class RobotAPI(Node):
    """Generate a new BCP core.

    Attributes
    ----------
    robot_status: `RobotStatus`
        The robot current status.
    robot_serial: `Serial`
        Onboard serial port object.

    Examples
    --------
    >>> from bubble_protocol.dispatch import RobotAPI
    >>> core = RobotAPI()
    """

    def __init__(self, name="standard") -> None:
        """
        Generate a new BCP core.
        初始化一个新的 BCP core类
        """
        super().__init__("BCP_Core")

        # Get params from ROS2 launch system
        self.declare_parameter('robot_type', 'None')
        self.declare_parameter('serial_port', 'None')
        self.name = self.get_parameter(
            'robot_type').get_parameter_value().string_value
        self.serial_port = self.get_parameter(
            'serial_port').get_parameter_value().string_value
        if self.name != 'None':
            self.get_logger().info(f'Robot {self.name} has been initialized...')
        else:
            self.get_logger().error(
                f'No robot has been initialized, please check the parameter Settings!')
            self.get_logger().error(
                f'Robot type:{name}')
            raise ValueError(
                'No robot has been initialized, please check the parameter Settings!')

        # Init robot core hardware
        serial_opened = False
        while not serial_opened:
            try:
                self.robot_serial = RobotSerial(name, port=self.serial_port)
                self.get_logger().info(f'Serial Port {self.serial_port} has been initialized...')
                serial_opened = True
            except Exception as e:
                self.get_logger().error(
                    f'Open serial port error, try to reopen port:{self.serial_port}, info: {e}')
                time.sleep(3)

        # 发布机器人状态模块
        self.robot_status = RobotStatus(self.robot_serial.status, self)
        self.robot_serial.realtime_pub = self.robot_status.realtime_callback
        self.robot_serial.serial_done = True

        # init core api
        self.api_init()
        # init expanded api
        self.init_robot()
        # Init robot tx/rx/heartbeat timer
        self.uart_timer = self.create_timer(0.01, self.robot_serial.process)
        self.uartrx_timer = self.create_timer(
            0.01, self.robot_serial.rx_function)
        # 心跳模块
        # self.heartbeat_timer = self.create_timer(0.5, self.heartbeat)

    def api_init(self) -> None:
        '''General information API of robot definition.
            机器人定义通用信息API。
        '''
        # heartbeat data initalized
        self.heartbeat_time = 0

        # subscriber api 订阅模式控制信息
        if self.name == "infantry" or self.name == "sentry_up":
            print("wwwwwwwwwwwwww")
            # self.gimbal_sub = self.create_subscription(
            #     Target, '/processor/target', self.gimbal_callback, qos.qos_profile_sensor_data)
            # self.gimbal_sub = sadawdawdawdf.create_subscription(
            #     Target, '/;;'processor/target', self.gimbal_callback, 10)
            self.gimbal_sub = self.create_subscription(
                Gimbal, '/processor/gimbal', self.gimbal_callback, 10)
            self.barrel_sub = self.create_subscription(
                Shooter, '/core/shooter_api', self.barrel_callback, 10)
            # print("Starting subscriber!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        # 2025/11/11 Change
        #elif self.name == "sentry_down":
            print("Starting subscriber!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            self.chassis_sub = self.create_subscription(
                Twist, '/cmd_vel', self.ex_chassis_callback, 10)

    def heartbeat(self):
        '''heartbeat function, send heartbeat frames periodically.
            心跳函数，周期性发送心跳帧。
        '''
        self.robot_serial.send_data("heartbeat", [self.heartbeat_time])
        # self.get_logger().info("heartbeat_time: {},time:{}".format(self.heartbeat_time,time.time()))
        self.heartbeat_time = 1 if self.heartbeat_time == 0 else 0

    def mode_ctrl_callback(self, msg: Int8) -> None:
        '''mode control function, send mode infomation to MCU.
            模式控制函数，发送模式信息给MCU。
        Parameters
        ------------
        msg: `Int8`
            A mode message is received
        '''
        # self.get_logger().info("recived data mode value: {}".format(msg.data))
        self.robot_serial.send_data("mode", [msg.data])

    def gimbal_callback(self, msg: Gimbal) -> None:
        """gimbal function, send gimbal infomation to MCU.
            云台功能，发送云台信息给MCU。
        Parameters
        ----------
        msg: `Gimbal`
            A mode message is received
        """

        # pitch = math.atan2(msg.position.z, math.sqrt(msg.position.x**2 + msg.position.y**2))
        # yaw = math.atan2(msg.position.y, msg.position.x)

        mode = 1
        #self.get_logger().info("recived data gimbal change, position.x: {}, position.y: {}, position.z: {}".format(
         #   msg.position.x, msg.position.y, msg.position.z))

        self.robot_serial.send_data(
            "gimbal",
            [mode, math.degrees(msg.yaw), math.degrees(msg.pitch), 0, 0, 0, 0])
        print(f"send data yaw:{msg.yaw},pitch{msg.pitch}")

    def barrel_callback(self, msg: Shooter) -> None:
        """Shooter function, send enable shooter infomation to MCU.
            射击功能，发送使能射击信息给MCU。
        Parameters
        ----------
        msg: `Shooter`
            A mode message is received
        """
        # self.get_logger().info("recived data barrel change, barrel: {}".format(msg.data))
        self.robot_serial.send_data(
            "barrel", [msg.is_shoot, msg.bullet_vel, msg.remain_bullet])

    def init_robot(self):
        """Expanded api definition, API required by the special robot is initialized.
            扩展api定义，初始化特殊机器人所需的API。
        Parameters
        ----------
        name: `str`
            robot name, name option reference 
            `The Chinese-English comparison table <https://birdiebot.github.io/bubble_documentation/guide/%E6%9C%AF%E8%AF%AD%E4%B8%AD%E8%8B%B1%E6%96%87%E5%AF%B9%E7%85%A7%E8%A1%A8.html>`__ .
        """
        if self.name == "sentry_up":
            pass
        elif self.name == "sentry_down":
            pass
        elif self.name == "infantry":
            pass

    def ex_chassis_callback(self, msg: Twist) -> None:
        """Chassis function, send chassis infomation to MCU.
            底盘功能，发送底盘信息给MCU
        Parameters
        ----------
        msg: `Chassis`
            A chassis message is received
        """
        print("recived data chassis")
        if msg.linear.x == 0 and msg.linear.y == 0:
            self.robot_serial.send_data("chassis_ctrl", [msg.linear.x, msg.linear.y, 1.0,
                                                     msg.angular.x, msg.angular.y, msg.angular.z])
        else:                                                    
            self.robot_serial.send_data("chassis_ctrl", [msg.linear.x, msg.linear.y, msg.linear.z,
                                                     msg.angular.x, msg.angular.y, msg.angular.z])

    def ex_odom_callback(self, msg: PoseWithCovariance):
        """Odom function, send chassis infomation to MCU.
            Odom函数，发送底盘信息给MCU。
        Parameters
        ----------
        msg: `PoseWithCovariance`
            A chassis message is received
        """
        odom_list = []
        odom_list.append(msg.pose.position.x)
        odom_list.append(msg.pose.position.y)
        odom_list.append(msg.pose.position.z)
        odom_list.append(msg.pose.orientation.x)
        odom_list.append(msg.pose.orientation.y)
        odom_list.append(msg.pose.orientation.z)
        odom_list.append(msg.pose.orientation.w)
        self.robot_serial.send_data("odom", odom_list)
